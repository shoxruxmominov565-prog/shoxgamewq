
ShoxRacing package
------------------
Files included:
- racing_shox.html   -> The game (open in browser)
- car.png            -> Car image used by the game
- Lola_Yuldasheva_Ketaver_Лола_Юлдашева_Кетавер_AUDIO.m4a   -> Audio file (copied from your upload)

How to use:
1. Unzip the package into a folder on your computer or upload the zip to a hosting service (GitHub Pages or CodePen).
2. Open racing_shox.html in a browser. If the browser blocks autoplay, click anywhere or press play on the page to start music.
3. To embed into Google Sites, host racing_shox.html on GitHub Pages or other host and use an <iframe> with the URL.

Controls:
- Left / Right arrow keys to move the car.
- On mobile, touch left/right side of canvas to move.
- Press R to restart when game over.

Notes:
- If audio doesn't play automatically, user interaction may be required due to browser autoplay policies.
